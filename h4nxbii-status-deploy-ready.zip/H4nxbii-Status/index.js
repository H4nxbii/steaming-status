
const { Client } = require('discord.js-selfbot-v13');
const express = require('express');
const app = express();
const port = process.env.PORT || 8000;

app.get('/', (req, res) => res.send('Bot is running'));
app.listen(port, () => console.log(`Web server running at http://localhost:${port}`));

const client = new Client({ checkUpdate: false });

const token = process.env.TOKEN;
if (!token) {
  console.error("❌ TOKEN not provided");
  process.exit(1);
}

client.login(token);

client.on('ready', () => {
  console.log(`${client.user.username} is online`);
  setInterval(() => {
    console.log('Bot still active...');
  }, 10000);
});
